# Azariah Credit Ltd - System Operation Manual

This manual explains how the core components of the loan management system function and how the workflow is managed between different official roles.

## 1. User & Staff Roles

- **Super Admin**: Full system control including deleting/locking admins and system-wide settings.
- **Admin**: General management of loans, users, and reports.
- **Manager**: Branch-specific oversight. Can verify and approve loans within their assigned branch.
- **Financial Officer**: Handles disbursements and tracks repayments.
- **Field Officer**: On-the-ground user registration and initial loan application processing.

## 2. Loan Lifecycle Workflow

The system enforces a strict state machine for loans to ensure oversight:

1.  **UNVERIFIED**: Loan application submitted (usually by Field Officer or user).
2.  **VERIFIED**: Manager checks documents and borrower history. Once verified, core details are locked.
3.  **APPROVED**: Final administrative check before funds are allocated.
4.  **DISBURSED**: Financial Officer triggers M-Pesa B2C or manual payout.
5.  **ACTIVE**: Loan is currently being repaid.
6.  **OVERDUE**: System automatically flags loans if a repayment schedule date passes without payment.
7.  **CLOSED**: Loan fully repaid.

## 3. Financial Engine

- **Interest Calculation**: Interest is calculated based on the Product settings (Inuka, Jijenge, Fadhili).
- **Grace Periods & Penalties**: The system automatically applies overdue penalties based on `SystemSettings` if a loan enters the `OVERDUE` state.
- **Ledger System**: Every disbursement and repayment creates a double-entry in the `SystemCapital` and `LedgerEntry` tables to ensure the balance sheet always matches.

## 4. Integrations

- **M-Pesa STK Push**: Allows users to pay loans directly from their phone.
- **M-Pesa B2C**: Allows automated disbursement of approved loans.
- **SMS Notifications**: Automated alerts for successful registration, loan approvals, and overdue reminders.

## 5. Reporting & Analytics

- Dashboard provides real-time totals of:
  - **Principal At Risk**: Total money out in the field.
  - **Total Portfolio**: Principal + Interest expected.
  - **Repayment Ratio**: Effectiveness of collections.
- **Pie Charts**: Show the distribution of loan products to identify the most popular services.
