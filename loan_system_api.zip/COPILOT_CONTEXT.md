---
# Azariah Credit Ltd — Copilot Context File

## What this project is
Full-stack loan management system. Field officers register customers
and process loans on their behalf. Customers never interact directly.

## Stack
- Backend: Django 5 + DRF + PostgreSQL (Neon DB) — runs on Render
- Frontend: React 19 + Vite + Tailwind CSS 4 — runs on Vercel
- Auth: JWT + bcrypt + pyotp (2FA)
- Payments: Safaricom Daraja API (Paybill only, no STK Push)
- SMS: Africa's Talking
- Email: Brevo SMTP

## Role hierarchy
Owner → Super Admin → Admin → Manager → Field Officer
Finance Officer sits cross-branch, invited only by Super Admin or Owner

## Invite rules
- Owner: can invite Super Admin, Admin
- Super Admin: can invite Admin, Finance Officer
- Admin: can invite Manager, Field Officer
- Manager: can invite Field Officer only
- Field Officer: cannot invite anyone
- Finance Officer: cannot invite anyone

## Loan lifecycle
UNVERIFIED → VERIFIED → APPROVED → DISBURSED → ACTIVE → OVERDUE → CLOSED
- Field Officer: submits and self-verifies
- Manager: approves or rejects
- Finance Officer: disburses only
- System: auto-detects OVERDUE, auto-closes when fully repaid

## Loan products
- Inuka: 25% flat rate
- Jijenge: 31.25% flat rate
- Fadhili: 36.35% flat rate

## Key frontend files
- src/components/layout/Sidebar.jsx — main sidebar, role-based links
- src/dashboards/owner/OwnerLayout.jsx — owner-only sidebar
- src/dashboards/AdminDashboard.jsx — admin routes
- src/dashboards/owner/OwnerDashboardWrapper.jsx — owner routes
- src/dashboards/ManagerDashboardWrapper.jsx — manager routes
- src/dashboards/FinanceDashboardWrapper.jsx — finance routes
- src/dashboards/FieldOfficerDashboardWrapper.jsx — field officer routes
- src/api/api.js — all API service functions
- src/context/AuthContext.jsx — auth state, user object
- src/components/ui/Shared.jsx — shared Table, Button, Card, Input components

## Key backend files
- apps/admins/views.py — admin management, invite logic
- apps/admins/auth_views.py — login, 2FA, password reset
- apps/authentication.py — JWT IP binding, threat logging
- apps/loans/views.py — loan CRUD and status transitions
- apps/users/views.py — customer registration
- apps/management/views.py — settings, capital, security logs
- apps/utils/security.py — log_action, get_filtered_queryset

## Permission rules
- Capital balance visible to: Owner, Super Admin, Finance Officer ONLY
- Security Logs visible to: Owner, Super Admin ONLY
- Security Threats page visible to: Owner, Super Admin ONLY
- Owner Audit visible to: Owner ONLY
- Finance Officer management: Super Admin and Owner ONLY
- Admin management: Super Admin and Owner ONLY

## What Admin role sees
- Managers, Field Officers, Customers, Loans
- Audit Logs, Customer Comms, Official Comms
- Settings: System tab and Branches tab only
- NOT: Super Admins table, Admins table, Finance Officers table,
  Security Logs, Capital Balance

## What Manager role sees
- Field Officers in their branch only
- Customers in their branch only
- Loans in their branch only
- Customer Comms, Official Comms
- NOT: any other staff tables, Settings, Logs, Capital Balance

## What Finance Officer sees
- Own finance dashboard only (Overview, Disbursement, Ledger etc)
- Available capital balance (balance only, not full breakdown)
- NOT: any officials tables, Settings, Audit Logs

## What Field Officer sees
- Own dashboard only (register customers, apply loans, verify loans)
- NOT: anything else

## Shared components rules
- Table component in Shared.jsx already has Show More/Less built in
- Never touch Shared.jsx directly
- Filtering and sorting is a mix of frontend-only and backend query params (Branch/Date).
- Loan workflow tables sort oldest first
- All other tables sort newest first

## Recent work — [LAST UPDATED: MARCH 22, 2026]
- **Unified Sidebar (UI)**: Grouped dashboard links under collapsible categories (Business Operations, Core Engine, Configuration) in `OwnerLayout.jsx` for a cleaner UI.
- **Multi-Parameter Filtering**: Added `Branch` and `Date Range` filters to `AdminCustomers.jsx` and `AdminLoans.jsx` with backend support in `SecurityMixin`.
- **RBAC Enforcement**: Restricted "Disburse" and "Bulk Disburse" buttons to the `FINANCE_OFFICER` roles only. The Owner role is explicitly blocked from these actions.
- **Bug Fixes**: 
  - Fixed syntax/compilation errors in `AdminCustomers.jsx` header.
  - Fixed empty Branch dropdowns in `AdminLoans.jsx` by correctly parsing paginated API results (`branchesData.results`).
---
