# Azariah Credit Ltd - Security Implementation Overview

This document outlines the multi-layered security measures implemented to protect the loan management system and its financial integrity.

## 1. Authentication & Access Control

- **Two-Factor Authentication (2FA)**: Mandatory TOTP-based 2FA using authenticators (Google, Microsoft) for all officials.
- **Login Attempt Tracking**:
  - System tracks failed login attempts by IP address and email.
  - **Automatic Lockout**: After 4 failed attempts, the account is locked for **20 minutes**.
- **Session Management**:
  - **Session Timeout**: JWT access tokens are set to a 10-minute lifetime to enforce auto-logout after inactivity.
  - **Secure Cookies**: HTTPS-only and SameSite flags are enforced in production.
- **Strict View-Level RBAC**: Unauthorized URL access is blocked at the API view level (403 Forbidden). Permissions are not just "hidden" on the UI; they are enforced on the backend.

## 2. Data Integrity & Tamper Prevention

- **Financial Immutability**:
  - Once a loan is `VERIFIED`, critical fields (Principal Amount, User ID, Interest Rate) are locked from further editing to prevent staff tampering.
  - **Delete Protection**: Financial records (Loans, Repayments, Transactions) have their `.delete()` methods overridden in the database layer to prevent any deletion, even by staff.
- **Audit Logging**:
  - Every sensitive action (Status change, Login, Data modification) is logged in the `AuditLogs` table.
  - Logs capture: **Administrator**, **Action**, **Timestamp**, **Affected Record ID**, **Old vs New Data**, and **IP Address**.

## 3. Infrastructure & Web Security

- **Database Security**:
  - Uses **PostgreSQL** for robust ACID compliance and relational integrity.
  - **Decimal Precision**: All financial calculations use `DecimalField(max_digits=12, decimal_places=2)` to avoid floating-point errors.
  - **ORM Only**: No raw SQL is used in the application layer, preventing SQL Injection.
- **Web Protections**:
  - **CSRF & XSS**: Django middle-ware is enabled for Cross-Site Request Forgery and Cross-Site Scripting protection.
  - **Secure Headers**:
    - `X-Frame-Options: DENY`: Prevents Clickjacking.
    - `SECURE_CONTENT_TYPE_NOSNIFF`: Prevents MIME-sniffing.
    - `SECURE_BROWSER_XSS_FILTER`: Enables browser-side XSS filters.
- **Production Hardening**:
  - `DEBUG = False`: Detailed error messages are suppressed in production.
  - **Environment Variables**: All sensitive credentials (DB passwords, M-Pesa keys, Secret keys) are stored in encrypted environment variables, never in the code.

## 4. Operational Oversight

- **Reason for Change**: Status changes (e.g., Rejecting a loan) require a written reason which is stored in the audit trail.
- **IP Tracking**: Every action is linked to the official's IP address to ensure accountability.
