import React from 'react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Utility function for Tailwind class merging
 */
export function cn(...inputs) {
  return twMerge(clsx(inputs));
}

/**
 * Button Component
 */
export const Button = ({ className, variant = 'primary', loading = false, children, ...props }) => {
  const variants = {
    primary: "bg-primary-600 text-white hover:bg-primary-700 shadow-sm",
    secondary: "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700 dark:hover:bg-slate-700",
    danger: "bg-red-600 text-white hover:bg-red-700 shadow-sm",
    ghost: "text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
  };

  return (
    <button
      disabled={loading || props.disabled}
      className={cn(
        "px-4 py-2 rounded-lg text-base font-medium transition-all focus:outline-none focus:ring-2 focus:ring-primary-500/20 disabled:opacity-50 flex items-center justify-center gap-2",
        variants[variant],
        className
      )}
      {...props}
    >
      {loading && (
        <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      )}
      {children}
    </button>
  );
};

/**
 * Input Component
 */
export const Input = ({ className, error, ...props }) => (
  <div className="w-full">
    <input
      className={cn(
        "w-full px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm text-slate-800 dark:text-slate-200 outline-none focus:ring-2 focus:ring-primary-500/50 transition-all disabled:opacity-50",
        error && "border-rose-500 focus:ring-rose-500/20",
        className
      )}
      {...props}
    />
    {error && <p className="mt-1 text-xs font-bold text-rose-500 pl-1 animate-in fade-in slide-in-from-top-1">{error}</p>}
  </div>
);

/**
 * Card Component
 */
export const Card = ({ className, children }) => (
  <div className={cn("bg-white rounded-xl border border-slate-200 shadow-sm dark:bg-slate-900 dark:border-slate-800 p-4 md:p-6", className)}>
    {children}
  </div>
);

/**
 * Table Component
 */
export const Table = ({ headers, data, renderRow, className, maxHeight = "max-h-[600px]", initialCount = 10 }) => {
  const [displayCount, setDisplayCount] = React.useState(initialCount);
  const hasMore = data && data.length > displayCount;
  const showLess = displayCount > initialCount;

  const visibleData = data ? data.slice(0, displayCount) : [];

  return (
    <div className={cn("w-full overflow-hidden rounded-lg border border-slate-200 dark:border-slate-800 flex flex-col", className)}>
      <div className={cn("overflow-x-auto overflow-y-auto", maxHeight)}>
        <table className="w-full text-sm md:text-base text-left min-w-[600px] border-collapse">
          <thead className="bg-slate-50 text-slate-600 dark:bg-slate-800/50 dark:text-slate-400 font-medium sticky top-0 z-10">
            <tr>
              {headers.map((h, i) => <th key={i} className="px-4 md:px-6 py-3 md:py-4 bg-slate-50 dark:bg-slate-800/90">{h}</th>)}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            {visibleData && visibleData.length > 0 ? (
              visibleData.map((item, i) => renderRow(item, i))
            ) : (
              <tr>
                <td colSpan={headers.length} className="px-6 py-8 text-center text-slate-500 font-bold italic">
                  No data available
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {(hasMore || showLess) && (
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-900/50 flex justify-center gap-4">
          {hasMore && (
            <button 
              onClick={() => setDisplayCount(prev => prev + 10)}
              className="text-xs font-black uppercase tracking-widest text-primary-600 hover:text-primary-700 dark:text-primary-400 flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-all font-bold"
            >
              Show More (+10)
            </button>
          )}
          {showLess && (
            <button 
              onClick={() => setDisplayCount(prev => Math.max(initialCount, prev - 10))}
              className="text-xs font-black uppercase tracking-widest text-slate-500 hover:text-slate-700 dark:text-slate-400 flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-all font-bold"
            >
              Show Less (-10)
            </button>
          )}
        </div>
      )}
    </div>
  );
};

/**
 * Stat Card
 */
export const StatCard = ({ label, value, icon: Icon, trend, trendValue, variant = 'primary', onClick }) => {
  const iconVariants = {
    primary: "bg-primary-50 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400",
    success: "bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400",
    warning: "bg-amber-50 text-amber-600 dark:bg-amber-900/20 dark:text-amber-400",
    danger: "bg-rose-50 text-rose-600 dark:bg-rose-900/20 dark:text-rose-400",
    info: "bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20 dark:text-indigo-400"
  };

  const isTrendUp = typeof trend === 'object' ? trend.isPositive : trend === 'up';
  const trendLabel = typeof trend === 'object' ? trend.value : `${trendValue}%`;

  return (
    <Card 
      className={cn(
        "flex items-center md:items-start justify-between p-3 md:p-6 transition-transform hover:scale-[1.02] active:scale-[0.98]",
        onClick && "cursor-pointer"
      )}
      onClick={onClick}
    >
      <div className="flex-1 min-w-0">
        <p className="text-xs md:text-base font-medium text-slate-500 dark:text-slate-400 truncate">{label}</p>
        <h3 className="text-lg md:text-3xl font-bold mt-0.5 md:mt-1 text-slate-800 dark:text-white truncate">{value}</h3>
        {trend && (
          <p className={cn("text-[8px] md:text-sm font-medium mt-1 md:mt-2 flex items-center gap-1", isTrendUp ? 'text-emerald-600' : 'text-rose-600')}>
            {isTrendUp ? '↑' : '↓'} {trendLabel}
          </p>
        )}
      </div>
      <div className={cn("p-1.5 md:p-3 rounded-lg shrink-0 ml-2", iconVariants[variant])}>
        <Icon className="w-4 h-4 md:w-6 md:h-6" />
      </div>
    </Card>
  );
};

/**
 * Badge Component
 */
export const Badge = ({ children, variant = 'secondary', className }) => {
  const variants = {
    primary: "bg-primary-50 text-primary-700 border-primary-100 dark:bg-primary-900/20 dark:text-primary-400 dark:border-primary-900/50",
    success: "bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-900/50",
    warning: "bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-900/50",
    danger: "bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-900/20 dark:text-rose-400 dark:border-rose-900/50",
    info: "bg-indigo-50 text-indigo-700 border-indigo-100 dark:bg-indigo-900/20 dark:text-indigo-400 dark:border-indigo-900/50",
    secondary: "bg-slate-50 text-slate-700 border-slate-100 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700"
  };

  return (
    <span className={cn(
      "px-2.5 py-0.5 rounded-full text-sm font-bold border",
      variants[variant],
      className
    )}>
      {children}
    </span>
  );
};

/**
 * Pagination Component
 */
export const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 sm:px-6">
      <div className="flex flex-1 justify-between sm:hidden">
        <Button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
          variant="secondary"
          size="sm"
        >
          Previous
        </Button>
        <Button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          variant="secondary"
          size="sm"
        >
          Next
        </Button>
      </div>
      <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
        <div>
          <p className="text-sm text-slate-700 dark:text-slate-400">
            Page <span className="font-bold text-primary-600">{currentPage}</span> of{' '}
            <span className="font-bold">{totalPages}</span>
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage <= 1}
          >
            Previous
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage >= totalPages}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};
