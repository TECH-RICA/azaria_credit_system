import django.db.models.deletion
import uuid
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('apps', '0011_smslog'),
    ]

    operations = [
        migrations.CreateModel(
            name='AdminInvitation',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('email', models.EmailField(max_length=254, unique=True)),
                ('role', models.CharField(max_length=50)),
                ('token', models.CharField(max_length=100, unique=True)),
                ('is_used', models.BooleanField(default=False)),
                ('expires_at', models.DateTimeField()),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('invited_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to='apps.admins')),
            ],
            options={
                'db_table': 'admin_invitations',
                'managed': True,
            },
        ),
    ]
